data:extend({
  {
    type = "item-subgroup",
    name = "space-connection-signals",
    group = "space",        -- put under Space Age signals
    order = "z"
  }
})